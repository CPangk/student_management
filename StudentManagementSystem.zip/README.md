# Student Management System (ASP.NET Core, EF Core, SQL Server)

## Overview
This is a sample Student Management System Web API built with:
- ASP.NET Core Web API
- Entity Framework Core (SQL Server)
- ASP.NET Core Identity (role-based auth; Admin and Student)
- JWT authentication

... (truncated for brevity in this file listing) ...
